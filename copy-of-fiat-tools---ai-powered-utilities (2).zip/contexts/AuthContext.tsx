import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { FirebaseUser, onAuthUserChanged, signInWithGoogle, signOutUser } from '../services/firebaseService';
import { OWNER_EMAIL } from '../constants';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  isOwner: boolean;
  isLoading: boolean;
  signIn: () => Promise<FirebaseUser | null>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isOwner, setIsOwner] = useState<boolean>(false);

  useEffect(() => {
    const unsubscribe = onAuthUserChanged((user) => {
      setCurrentUser(user);
      setIsOwner(user?.email === OWNER_EMAIL);
      setIsLoading(false);
    });
    return () => unsubscribe(); // Cleanup subscription on unmount
  }, []);

  const signIn = async (): Promise<FirebaseUser | null> => {
    setIsLoading(true);
    try {
      const user = await signInWithGoogle();
      setCurrentUser(user);
      setIsOwner(user?.email === OWNER_EMAIL);
      setIsLoading(false);
      return user;
    } catch (error) {
      console.error("Sign in failed in AuthContext", error);
      setIsLoading(false);
      // Optionally, handle specific error types or set an error state
      return null;
    }
  };

  const signOut = async (): Promise<void> => {
    setIsLoading(true);
    try {
      await signOutUser();
      setCurrentUser(null);
      setIsOwner(false);
    } catch (error) {
       console.error("Sign out failed in AuthContext", error);
       // Optionally, handle specific error types or set an error state
    } finally {
        setIsLoading(false);
    }
  };

  const value = {
    currentUser,
    isOwner,
    isLoading,
    signIn,
    signOut,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
