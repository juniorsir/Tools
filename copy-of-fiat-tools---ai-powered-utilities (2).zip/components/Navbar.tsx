import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import { APP_NAME, NAV_LINKS_BASE, OWNER_NAV_LINK } from '../constants';
import { useAuth } from '../contexts/AuthContext';
import { LoadingSpinner } from './common/LoadingSpinner';

export const Navbar: React.FC = () => {
  const { currentUser, isOwner, isLoading, signIn, signOut } = useAuth();

  const navLinks = [...NAV_LINKS_BASE];
  if (currentUser && isOwner) {
    navLinks.push(OWNER_NAV_LINK);
  }

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="text-2xl font-bold text-blue-600 hover:text-blue-700 transition-colors">
            {APP_NAME}
          </Link>
          <div className="flex items-center space-x-2 sm:space-x-4">
            {navLinks.map((link) => (
              <NavLink
                key={link.name}
                to={link.path}
                className={({ isActive }) =>
                  `flex items-center px-3 py-2 rounded-md text-sm font-medium transition-all duration-150 ease-in-out
                   ${isActive
                     ? 'bg-blue-500 text-white shadow-sm'
                     : 'text-gray-600 hover:bg-gray-200 hover:text-gray-900'
                   }`
                }
              >
                {link.icon}
                <span className="hidden sm:inline">{link.name}</span>
              </NavLink>
            ))}
            
            <div className="flex items-center ml-2 sm:ml-4">
              {isLoading ? (
                <div className="w-8 h-8"><LoadingSpinner/></div>
              ) : currentUser ? (
                <div className="relative group">
                  <button className="flex items-center focus:outline-none">
                    {currentUser.photoURL ? (
                      <img
                        src={currentUser.photoURL}
                        alt={currentUser.displayName || 'User'}
                        className="w-8 h-8 rounded-full border-2 border-gray-300 group-hover:border-blue-500 transition-colors"
                      />
                    ) : (
                      <span className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center text-gray-600 text-sm font-semibold">
                        {currentUser.displayName?.charAt(0) || currentUser.email?.charAt(0) || 'U'}
                      </span>
                    )}
                    <span className="hidden sm:inline ml-2 text-sm text-gray-700 group-hover:text-blue-600">
                      {currentUser.displayName?.split(' ')[0] || 'Profile'}
                    </span>
                  </button>
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20 opacity-0 group-hover:opacity-100 transition-opacity duration-200 transform scale-95 group-hover:scale-100 origin-top-right invisible group-hover:visible">
                    <div className="px-4 py-2 text-sm text-gray-700">
                      Signed in as <br/>
                      <strong className="truncate block">{currentUser.displayName || currentUser.email}</strong>
                    </div>
                    <div className="border-t border-gray-100"></div>
                    <button
                      onClick={signOut}
                      className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-gray-900"
                      aria-label="Sign out"
                    >
                      Sign Out
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={signIn}
                  className="px-3 py-2 rounded-md text-sm font-medium bg-blue-500 text-white hover:bg-blue-600 transition-colors"
                  aria-label="Sign in with Google"
                >
                  Sign in
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};
