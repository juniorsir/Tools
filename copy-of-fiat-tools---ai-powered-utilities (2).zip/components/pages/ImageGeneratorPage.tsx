
import React, { useState, useCallback } from 'react';
import { generateImageWithGemini } from '../../services/geminiService';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { ErrorMessage } from '../common/ErrorMessage';
import { PageWrapper } from '../common/PageWrapper';
import { PhotoIcon } from '../../constants';

export const ImageGeneratorPage: React.FC = () => {
  const [prompt, setPrompt] = useState<string>('');
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async (event: React.FormEvent) => {
    event.preventDefault();
    if (!prompt.trim()) {
      setError('Please enter a prompt to generate an image.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedImage(null);

    try {
      const imageUrl = await generateImageWithGemini(prompt);
      setGeneratedImage(imageUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred during image generation.');
      console.error("Image generation error:", err);
    } finally {
      setIsLoading(false);
    }
  }, [prompt]);

  return (
    <PageWrapper title="Image Generator">
       <div className="flex items-center text-gray-600 mb-6">
        <PhotoIcon className="w-8 h-8 mr-3 text-purple-500" />
        <p className="text-lg">
          Describe the image you want to create. Our AI will bring your vision to life.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="prompt-input" className="block text-sm font-medium text-gray-700 mb-1">
            Image Prompt
          </label>
          <input
            type="text"
            id="prompt-input"
            className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition duration-150 ease-in-out"
            placeholder="e.g., A futuristic cityscape at sunset"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            disabled={isLoading}
          />
        </div>

        <button
          type="submit"
          disabled={isLoading || !prompt.trim()}
          className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition duration-150 ease-in-out"
        >
          {isLoading ? (
            <>
              <LoadingSpinner /> <span className="ml-2">Generating...</span>
            </>
          ) : (
            'Generate Image'
          )}
        </button>
      </form>

      {error && <ErrorMessage message={error} />}

      {generatedImage && (
        <div className="mt-8 p-6 bg-gray-50 rounded-lg shadow">
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">Generated Image:</h3>
          <div className="flex justify-center">
            <img 
              src={generatedImage} 
              alt={prompt} 
              className="max-w-full h-auto max-h-[512px] rounded-lg shadow-md border border-gray-200" 
            />
          </div>
           <div className="mt-4 text-center">
            <a 
              href={generatedImage} 
              download={`generated-image-${Date.now()}.png`}
              className="inline-block px-4 py-2 bg-green-500 text-white font-medium rounded-md hover:bg-green-600 transition-colors"
            >
              Download Image
            </a>
          </div>
        </div>
      )}
    </PageWrapper>
  );
};
