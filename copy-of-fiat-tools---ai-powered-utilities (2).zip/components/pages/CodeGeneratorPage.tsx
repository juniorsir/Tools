import React, { useState, useCallback } from 'react';
import { generateCode } from '../../services/geminiService';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { ErrorMessage } from '../common/ErrorMessage';
import { PageWrapper } from '../common/PageWrapper';
import { CodeBracketIcon } from '../../constants';
import { CodeGenerationResult } from '../../types';

const LANGUAGES = [
  "Python", "JavaScript", "TypeScript", "Java", "C++", "C#", "Go", "Ruby", "PHP", "Swift", "Kotlin", "Rust"
];

export const CodeGeneratorPage: React.FC = () => {
  const [problemDescription, setProblemDescription] = useState<string>('');
  const [language, setLanguage] = useState<string>(LANGUAGES[0]);
  const [specificRequirements, setSpecificRequirements] = useState<string>('');
  const [generatedCode, setGeneratedCode] = useState<CodeGenerationResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async (event: React.FormEvent) => {
    event.preventDefault();
    if (!problemDescription.trim()) {
      setError('Please enter a problem description.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedCode(null);

    try {
      const result = await generateCode(problemDescription, language, specificRequirements);
      setGeneratedCode(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred during code generation.');
      console.error("Code generation error:", err);
    } finally {
      setIsLoading(false);
    }
  }, [problemDescription, language, specificRequirements]);

  return (
    <PageWrapper title="Code Generator">
      <div className="flex items-center text-gray-600 mb-6">
        <CodeBracketIcon className="w-8 h-8 mr-3 text-indigo-500" />
        <p className="text-lg">
          Describe a programming problem, select a language, and let AI generate the code and explanation.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="problemDescription" className="block text-sm font-medium text-gray-700 mb-1">
            Problem Description
          </label>
          <textarea
            id="problemDescription"
            rows={5}
            className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-150 ease-in-out"
            placeholder="e.g., Write a Python function to sort a list of numbers in ascending order."
            value={problemDescription}
            onChange={(e) => setProblemDescription(e.target.value)}
            disabled={isLoading}
            required
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label htmlFor="language" className="block text-sm font-medium text-gray-700 mb-1">
                    Programming Language
                </label>
                <select
                    id="language"
                    className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-150 ease-in-out bg-white"
                    value={language}
                    onChange={(e) => setLanguage(e.target.value)}
                    disabled={isLoading}
                >
                    {LANGUAGES.map(lang => <option key={lang} value={lang}>{lang}</option>)}
                </select>
            </div>
            <div>
                <label htmlFor="specificRequirements" className="block text-sm font-medium text-gray-700 mb-1">
                    Specific Requirements (optional)
                </label>
                <input
                    type="text"
                    id="specificRequirements"
                    className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-150 ease-in-out"
                    placeholder="e.g., Must use recursion, optimize for speed"
                    value={specificRequirements}
                    onChange={(e) => setSpecificRequirements(e.target.value)}
                    disabled={isLoading}
                />
            </div>
        </div>


        <button
          type="submit"
          disabled={isLoading || !problemDescription.trim()}
          className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition duration-150 ease-in-out"
        >
          {isLoading ? (
            <>
              <LoadingSpinner /> <span className="ml-2">Generating Code...</span>
            </>
          ) : (
            'Generate Code'
          )}
        </button>
      </form>

      {error && <ErrorMessage message={error} />}

      {generatedCode && (
        <div className="mt-8 p-6 bg-gray-50 rounded-lg shadow">
          <h3 className="text-2xl font-semibold text-gray-800 mb-1">Generated Code</h3>
          <p className="text-sm text-gray-600 mb-4">Language: {generatedCode.language}</p>
          
          <div className="mb-6">
            <pre><code>{generatedCode.generatedCode}</code></pre>
          </div>

          <div>
            <h4 className="text-xl font-semibold text-gray-800 mb-2">Explanation:</h4>
            <div className="prose prose-indigo max-w-none text-gray-700 whitespace-pre-wrap">
              {generatedCode.explanation}
            </div>
          </div>
        </div>
      )}
    </PageWrapper>
  );
};