import React, { useState, useCallback } from 'react';
import { generateStory } from '../../services/geminiService';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { ErrorMessage } from '../common/ErrorMessage';
import { PageWrapper } from '../common/PageWrapper';
import { BookOpenIcon } from '../../constants';
import { StoryResult } from '../../types';

const STORY_LENGTHS: { label: string; promptDetail: string }[] = [
  { label: "Short", promptDetail: "about 300 words" },
  { label: "Medium", promptDetail: "about 700 words" },
  { label: "Long", promptDetail: "about 1500 words" },
];

export const StoryWriterPage: React.FC = () => {
  const [genre, setGenre] = useState<string>('');
  const [characters, setCharacters] = useState<string>('');
  const [plotOutline, setPlotOutline] = useState<string>('');
  const [storyLength, setStoryLength] = useState<string>(STORY_LENGTHS[0].promptDetail);
  const [generatedStory, setGeneratedStory] = useState<StoryResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async (event: React.FormEvent) => {
    event.preventDefault();
    if (!genre.trim() && !plotOutline.trim()) {
      setError('Please provide a genre or some plot ideas.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedStory(null);

    try {
      const result = await generateStory(genre, characters, plotOutline, storyLength);
      setGeneratedStory(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred during story generation.');
      console.error("Story generation error:", err);
    } finally {
      setIsLoading(false);
    }
  }, [genre, characters, plotOutline, storyLength]);

  return (
    <PageWrapper title="AI Story Writer">
      <div className="flex items-center text-gray-600 mb-6">
        <BookOpenIcon className="w-8 h-8 mr-3 text-pink-500" />
        <p className="text-lg">
          Craft your unique story with AI. Provide some details, and let the magic happen!
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="genre" className="block text-sm font-medium text-gray-700 mb-1">
            Genre
          </label>
          <input
            type="text"
            id="genre"
            className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition duration-150 ease-in-out"
            placeholder="e.g., Sci-Fi, Fantasy, Mystery, Romance"
            value={genre}
            onChange={(e) => setGenre(e.target.value)}
            disabled={isLoading}
          />
        </div>

        <div>
          <label htmlFor="characters" className="block text-sm font-medium text-gray-700 mb-1">
            Main Characters (names, brief descriptions - optional)
          </label>
          <textarea
            id="characters"
            rows={3}
            className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition duration-150 ease-in-out"
            placeholder="e.g., Elara, a brave space explorer; Kael, a mysterious sorcerer"
            value={characters}
            onChange={(e) => setCharacters(e.target.value)}
            disabled={isLoading}
          />
        </div>
        
        <div>
          <label htmlFor="plotOutline" className="block text-sm font-medium text-gray-700 mb-1">
            Plot Outline or Key Ideas
          </label>
          <textarea
            id="plotOutline"
            rows={4}
            className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition duration-150 ease-in-out"
            placeholder="e.g., A hidden artifact is discovered, leading to an epic quest across forgotten lands."
            value={plotOutline}
            onChange={(e) => setPlotOutline(e.target.value)}
            disabled={isLoading}
          />
        </div>

        <div>
            <label htmlFor="storyLength" className="block text-sm font-medium text-gray-700 mb-1">
                Desired Story Length
            </label>
            <select
                id="storyLength"
                className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition duration-150 ease-in-out bg-white"
                value={storyLength}
                onChange={(e) => setStoryLength(e.target.value)}
                disabled={isLoading}
            >
                {STORY_LENGTHS.map(len => <option key={len.label} value={len.promptDetail}>{len.label} ({len.promptDetail})</option>)}
            </select>
        </div>

        <button
          type="submit"
          disabled={isLoading || (!genre.trim() && !plotOutline.trim())}
          className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-pink-600 hover:bg-pink-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition duration-150 ease-in-out"
        >
          {isLoading ? (
            <>
              <LoadingSpinner /> <span className="ml-2">Writing Story...</span>
            </>
          ) : (
            'Generate Story'
          )}
        </button>
      </form>

      {error && <ErrorMessage message={error} />}

      {generatedStory && (
        <div className="mt-8 p-6 bg-gray-50 rounded-lg shadow">
          <h2 className="text-3xl font-bold text-gray-800 mb-2">{generatedStory.title || "Untitled Story"}</h2>
          {generatedStory.genre && <p className="text-sm text-gray-600 italic mb-1">Genre: {generatedStory.genre}</p>}
          {generatedStory.charactersInvolved && generatedStory.charactersInvolved.length > 0 && (
             <p className="text-sm text-gray-600 mb-4">Characters: {generatedStory.charactersInvolved.join(', ')}</p>
          )}
          
          <div className="prose prose-pink max-w-none text-gray-700 whitespace-pre-wrap">
            {generatedStory.story}
          </div>
        </div>
      )}
    </PageWrapper>
  );
};