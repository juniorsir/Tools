import React, { useState, useCallback } from 'react';
import { generateRecipe } from '../../services/geminiService';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { ErrorMessage } from '../common/ErrorMessage';
import { PageWrapper } from '../common/PageWrapper';
import { ChefHatIcon } from '../../constants';
import { Recipe, RecipeIngredient } from '../../types';

export const RecipeGeneratorPage: React.FC = () => {
  const [ingredients, setIngredients] = useState<string>('');
  const [dietaryRestrictions, setDietaryRestrictions] = useState<string>('');
  const [cuisineType, setCuisineType] = useState<string>('');
  const [mealType, setMealType] = useState<string>('any');
  const [generatedRecipe, setGeneratedRecipe] = useState<Recipe | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async (event: React.FormEvent) => {
    event.preventDefault();
    if (!ingredients.trim() && !cuisineType.trim()) {
      setError('Please provide some ingredients or specify a cuisine type.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedRecipe(null);

    try {
      const result = await generateRecipe(ingredients, dietaryRestrictions, cuisineType, mealType);
      setGeneratedRecipe(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred during recipe generation.');
      console.error("Recipe generation error:", err);
    } finally {
      setIsLoading(false);
    }
  }, [ingredients, dietaryRestrictions, cuisineType, mealType]);

  const mealTypes = ["any", "Breakfast", "Lunch", "Dinner", "Snack", "Dessert"];

  return (
    <PageWrapper title="Recipe Generator">
      <div className="flex items-center text-gray-600 mb-6">
        <ChefHatIcon className="w-8 h-8 mr-3 text-green-500" />
        <p className="text-lg">
          Tell us what you have or what you're in the mood for, and we'll whip up a recipe!
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="ingredients" className="block text-sm font-medium text-gray-700 mb-1">
            Available Ingredients (comma-separated)
          </label>
          <textarea
            id="ingredients"
            rows={3}
            className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition duration-150 ease-in-out"
            placeholder="e.g., chicken breast, broccoli, rice, soy sauce"
            value={ingredients}
            onChange={(e) => setIngredients(e.target.value)}
            disabled={isLoading}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="dietaryRestrictions" className="block text-sm font-medium text-gray-700 mb-1">
              Dietary Restrictions (optional)
            </label>
            <input
              type="text"
              id="dietaryRestrictions"
              className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition duration-150 ease-in-out"
              placeholder="e.g., gluten-free, vegan, nut-free"
              value={dietaryRestrictions}
              onChange={(e) => setDietaryRestrictions(e.target.value)}
              disabled={isLoading}
            />
          </div>
          <div>
            <label htmlFor="cuisineType" className="block text-sm font-medium text-gray-700 mb-1">
              Cuisine Type (optional)
            </label>
            <input
              type="text"
              id="cuisineType"
              className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition duration-150 ease-in-out"
              placeholder="e.g., Italian, Mexican, Indian"
              value={cuisineType}
              onChange={(e) => setCuisineType(e.target.value)}
              disabled={isLoading}
            />
          </div>
        </div>
         <div>
            <label htmlFor="mealType" className="block text-sm font-medium text-gray-700 mb-1">
              Meal Type
            </label>
            <select
              id="mealType"
              className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition duration-150 ease-in-out bg-white"
              value={mealType}
              onChange={(e) => setMealType(e.target.value)}
              disabled={isLoading}
            >
              {mealTypes.map(type => <option key={type} value={type}>{type === "any" ? "Any Meal Type" : type}</option>)}
            </select>
          </div>

        <button
          type="submit"
          disabled={isLoading || (!ingredients.trim() && !cuisineType.trim())}
          className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition duration-150 ease-in-out"
        >
          {isLoading ? (
            <>
              <LoadingSpinner /> <span className="ml-2">Generating Recipe...</span>
            </>
          ) : (
            'Generate Recipe'
          )}
        </button>
      </form>

      {error && <ErrorMessage message={error} />}

      {generatedRecipe && (
        <div className="mt-8 p-6 bg-gray-50 rounded-lg shadow">
          <h2 className="text-3xl font-bold text-gray-800 mb-3">{generatedRecipe.recipeName}</h2>
          <p className="text-gray-600 italic mb-4">{generatedRecipe.description}</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 text-sm text-gray-700">
            <span><strong>Prep Time:</strong> {generatedRecipe.prepTime}</span>
            <span><strong>Cook Time:</strong> {generatedRecipe.cookTime}</span>
            <span><strong>Servings:</strong> {generatedRecipe.servings}</span>
            {generatedRecipe.cuisineType && <span><strong>Cuisine:</strong> {generatedRecipe.cuisineType}</span>}
            {generatedRecipe.mealType && <span><strong>Meal:</strong> {generatedRecipe.mealType}</span>}
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Ingredients:</h3>
            <ul className="list-disc list-inside space-y-1 text-gray-700">
              {generatedRecipe.ingredients.map((ing: RecipeIngredient, index: number) => (
                <li key={index}>{ing.quantity} {ing.name}</li>
              ))}
            </ul>
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Instructions:</h3>
            <ol className="list-decimal list-inside space-y-2 text-gray-700">
              {generatedRecipe.instructions.map((step: string, index: number) => (
                <li key={index}>{step}</li>
              ))}
            </ol>
          </div>

          {generatedRecipe.notes && (
            <div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Notes:</h3>
              <p className="text-gray-700 whitespace-pre-wrap">{generatedRecipe.notes}</p>
            </div>
          )}
        </div>
      )}
    </PageWrapper>
  );
};
