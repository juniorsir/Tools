import React, { useState, useCallback } from 'react';
import { generateWorkoutPlan } from '../../services/geminiService';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { ErrorMessage } from '../common/ErrorMessage';
import { PageWrapper } from '../common/PageWrapper';
import { DumbbellIcon } from '../../constants';
import { WorkoutPlan, WorkoutDay, WorkoutExercise } from '../../types';

export const WorkoutPlannerPage: React.FC = () => {
  const [fitnessGoal, setFitnessGoal] = useState<string>('');
  const [timePerSession, setTimePerSession] = useState<string>('45 minutes');
  const [fitnessLevel, setFitnessLevel] = useState<string>('Intermediate');
  const [preferredActivities, setPreferredActivities] = useState<string>('');
  const [daysPerWeek, setDaysPerWeek] = useState<number>(3);
  const [generatedPlan, setGeneratedPlan] = useState<WorkoutPlan | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async (event: React.FormEvent) => {
    event.preventDefault();
    if (!fitnessGoal.trim()) {
      setError('Please describe your fitness goal.');
      return;
    }
    if (daysPerWeek < 1 || daysPerWeek > 7) {
      setError('Days per week must be between 1 and 7.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedPlan(null);

    try {
      const result = await generateWorkoutPlan(fitnessGoal, timePerSession, fitnessLevel, preferredActivities, daysPerWeek);
      setGeneratedPlan(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred during workout plan generation.');
      console.error("Workout plan error:", err);
    } finally {
      setIsLoading(false);
    }
  }, [fitnessGoal, timePerSession, fitnessLevel, preferredActivities, daysPerWeek]);

  const timeOptions = ["30 minutes", "45 minutes", "60 minutes", "75 minutes", "90 minutes"];
  const levelOptions = ["Beginner", "Intermediate", "Advanced"];

  return (
    <PageWrapper title="Workout Planner">
      <div className="flex items-center text-gray-600 mb-6">
        <DumbbellIcon className="w-8 h-8 mr-3 text-red-500" />
        <p className="text-lg">
          Get a personalized workout plan to achieve your fitness objectives.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="fitnessGoal" className="block text-sm font-medium text-gray-700 mb-1">
            Primary Fitness Goal
          </label>
          <textarea
            id="fitnessGoal"
            rows={3}
            className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-red-500 focus:border-red-500 transition duration-150 ease-in-out"
            placeholder="e.g., Lose 5kg in 2 months, build upper body strength, run a 5K"
            value={fitnessGoal}
            onChange={(e) => setFitnessGoal(e.target.value)}
            disabled={isLoading}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div>
            <label htmlFor="timePerSession" className="block text-sm font-medium text-gray-700 mb-1">
              Time per Session
            </label>
            <select
              id="timePerSession"
              className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-red-500 focus:border-red-500 transition duration-150 ease-in-out bg-white"
              value={timePerSession}
              onChange={(e) => setTimePerSession(e.target.value)}
              disabled={isLoading}
            >
              {timeOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="fitnessLevel" className="block text-sm font-medium text-gray-700 mb-1">
              Fitness Level
            </label>
            <select
              id="fitnessLevel"
              className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-red-500 focus:border-red-500 transition duration-150 ease-in-out bg-white"
              value={fitnessLevel}
              onChange={(e) => setFitnessLevel(e.target.value)}
              disabled={isLoading}
            >
              {levelOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="daysPerWeek" className="block text-sm font-medium text-gray-700 mb-1">
              Days per Week (1-7)
            </label>
            <input
              type="number"
              id="daysPerWeek"
              min="1" max="7"
              className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-red-500 focus:border-red-500 transition duration-150 ease-in-out"
              value={daysPerWeek}
              onChange={(e) => setDaysPerWeek(parseInt(e.target.value))}
              disabled={isLoading}
            />
          </div>
        </div>

        <div>
          <label htmlFor="preferredActivities" className="block text-sm font-medium text-gray-700 mb-1">
            Preferred Activities/Equipment (optional)
          </label>
          <input
            type="text"
            id="preferredActivities"
            className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-red-500 focus:border-red-500 transition duration-150 ease-in-out"
            placeholder="e.g., Bodyweight, dumbbells, running, yoga, no jumping"
            value={preferredActivities}
            onChange={(e) => setPreferredActivities(e.target.value)}
            disabled={isLoading}
          />
        </div>

        <button
          type="submit"
          disabled={isLoading || !fitnessGoal.trim()}
          className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition duration-150 ease-in-out"
        >
          {isLoading ? (
            <>
              <LoadingSpinner /> <span className="ml-2">Generating Plan...</span>
            </>
          ) : (
            'Generate Workout Plan'
          )}
        </button>
      </form>

      {error && <ErrorMessage message={error} />}

      {generatedPlan && (
        <div className="mt-8 p-6 bg-gray-50 rounded-lg shadow">
          <h2 className="text-3xl font-bold text-gray-800 mb-2">{generatedPlan.planName}</h2>
          {generatedPlan.description && <p className="text-gray-600 italic mb-1">{generatedPlan.description}</p>}
          <p className="text-sm text-gray-500 mb-4">
            Goal: {generatedPlan.goal || 'Not specified'} | Level: {generatedPlan.fitnessLevel || 'Any'} | Days/Week: {generatedPlan.daysPerWeek || 'As specified'}
          </p>

          <div className="space-y-6">
            {generatedPlan.dailySchedule?.map((day: WorkoutDay, dayIndex: number) => (
              <details key={dayIndex} className="bg-white p-4 rounded-lg shadow-sm group" open={dayIndex === 0}>
                <summary className="font-semibold text-xl text-red-700 cursor-pointer group-hover:text-red-800">
                  {day.dayOfWeek || `Day ${dayIndex + 1}`}: {day.focus}
                </summary>
                <div className="mt-3 space-y-3 text-gray-700">
                  {day.warmUp && day.warmUp.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-md">Warm-up:</h4>
                      <ul className="list-disc list-inside ml-4 text-sm">
                        {day.warmUp.map((item, i) => <li key={`wu-${i}`}>{item}</li>)}
                      </ul>
                    </div>
                  )}
                  <div>
                    <h4 className="font-semibold text-md">Exercises:</h4>
                    <ul className="space-y-1 ml-4 text-sm">
                      {day.exercises.map((ex: WorkoutExercise, exIndex: number) => (
                        <li key={exIndex}>
                          <strong>{ex.name}:</strong> {ex.sets} sets of {ex.reps}
                          {ex.duration && ` for ${ex.duration}`}
                          {ex.rest && ` (Rest: ${ex.rest})`}
                        </li>
                      ))}
                    </ul>
                  </div>
                  {day.coolDown && day.coolDown.length > 0 && (
                     <div>
                      <h4 className="font-semibold text-md">Cool-down:</h4>
                      <ul className="list-disc list-inside ml-4 text-sm">
                        {day.coolDown.map((item, i) => <li key={`cd-${i}`}>{item}</li>)}
                      </ul>
                    </div>
                  )}
                </div>
              </details>
            ))}
          </div>

          {generatedPlan.notes && (
            <div className="mt-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-2">General Notes:</h3>
              <p className="text-gray-700 whitespace-pre-wrap">{generatedPlan.notes}</p>
            </div>
          )}
        </div>
      )}
    </PageWrapper>
  );
};
