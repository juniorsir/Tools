import React, { useState, useCallback } from 'react';
import { generateTravelItinerary } from '../../services/geminiService';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { ErrorMessage } from '../common/ErrorMessage';
import { PageWrapper } from '../common/PageWrapper';
import { GlobeIcon } from '../../constants';
import { TravelItinerary, DailyItinerary, ItineraryActivity } from '../../types';

export const TravelItineraryPage: React.FC = () => {
  const [destination, setDestination] = useState<string>('');
  const [durationInDays, setDurationInDays] = useState<number>(3);
  const [interests, setInterests] = useState<string>('');
  const [budget, setBudget] = useState<string>('Mid-range');
  const [generatedItinerary, setGeneratedItinerary] = useState<TravelItinerary | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async (event: React.FormEvent) => {
    event.preventDefault();
    if (!destination.trim()) {
      setError('Please enter a destination.');
      return;
    }
    if (durationInDays < 1 || durationInDays > 30) {
      setError('Duration must be between 1 and 30 days.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedItinerary(null);

    try {
      const result = await generateTravelItinerary(destination, durationInDays, interests, budget);
      setGeneratedItinerary(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred during itinerary generation.');
      console.error("Itinerary generation error:", err);
    } finally {
      setIsLoading(false);
    }
  }, [destination, durationInDays, interests, budget]);

  const budgetOptions = ["Budget", "Mid-range", "Luxury"];

  const renderActivity = (activity: ItineraryActivity | undefined, period: string) => {
    if (!activity || !activity.activity) return <p className="text-sm text-gray-500">No specific {period.toLowerCase()} activity planned.</p>;
    return (
      <div className="mb-2">
        <strong className="text-sm">{activity.activity}</strong>
        {activity.location && <span className="text-xs text-gray-500"> (@ {activity.location})</span>}
        {activity.description && <p className="text-xs text-gray-600 pl-2">- {activity.description}</p>}
        {activity.estimatedTime && <p className="text-xs text-gray-500 pl-2">Est. Time: {activity.estimatedTime}</p>}
      </div>
    );
  };


  return (
    <PageWrapper title="Travel Itinerary Planner">
      <div className="flex items-center text-gray-600 mb-6">
        <GlobeIcon className="w-8 h-8 mr-3 text-yellow-500" />
        <p className="text-lg">
          Plan your next adventure! Describe your trip, and we'll suggest an itinerary.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="destination" className="block text-sm font-medium text-gray-700 mb-1">
            Destination
          </label>
          <input
            type="text"
            id="destination"
            className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition duration-150 ease-in-out"
            placeholder="e.g., Paris, France"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            disabled={isLoading}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="durationInDays" className="block text-sm font-medium text-gray-700 mb-1">
              Duration (days, 1-30)
            </label>
            <input
              type="number"
              id="durationInDays"
              min="1" max="30"
              className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition duration-150 ease-in-out"
              value={durationInDays}
              onChange={(e) => setDurationInDays(parseInt(e.target.value))}
              disabled={isLoading}
            />
          </div>
          <div>
            <label htmlFor="budget" className="block text-sm font-medium text-gray-700 mb-1">
              Budget Level
            </label>
            <select
              id="budget"
              className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition duration-150 ease-in-out bg-white"
              value={budget}
              onChange={(e) => setBudget(e.target.value)}
              disabled={isLoading}
            >
              {budgetOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </select>
          </div>
        </div>
        
        <div>
          <label htmlFor="interests" className="block text-sm font-medium text-gray-700 mb-1">
            Interests & Preferences (optional)
          </label>
          <textarea
            id="interests"
            rows={3}
            className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition duration-150 ease-in-out"
            placeholder="e.g., Museums, historical sites, local food, hiking, nightlife, relaxing"
            value={interests}
            onChange={(e) => setInterests(e.target.value)}
            disabled={isLoading}
          />
        </div>

        <button
          type="submit"
          disabled={isLoading || !destination.trim()}
          className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-yellow-600 hover:bg-yellow-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition duration-150 ease-in-out"
        >
          {isLoading ? (
            <>
              <LoadingSpinner /> <span className="ml-2">Generating Itinerary...</span>
            </>
          ) : (
            'Generate Itinerary'
          )}
        </button>
      </form>

      {error && <ErrorMessage message={error} />}

      {generatedItinerary && (
        <div className="mt-8 p-6 bg-gray-50 rounded-lg shadow">
          <h2 className="text-3xl font-bold text-gray-800 mb-2">{generatedItinerary.tripName}</h2>
          <p className="text-sm text-gray-500 mb-1">Destination: {generatedItinerary.destination} | Duration: {generatedItinerary.durationDays} days</p>
          {generatedItinerary.budgetLevel && <p className="text-sm text-gray-500 mb-1">Budget: {generatedItinerary.budgetLevel}</p>}
          {generatedItinerary.interestsMentioned && generatedItinerary.interestsMentioned.length > 0 && (
            <p className="text-sm text-gray-500 mb-4">Interests: {generatedItinerary.interestsMentioned.join(', ')}</p>
          )}


          {generatedItinerary.overallNotes && (
            <div className="mb-4 p-3 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700">
              <h4 className="font-semibold">Quick Tips:</h4>
              <p className="text-sm whitespace-pre-wrap">{generatedItinerary.overallNotes}</p>
            </div>
          )}
          
          <div className="space-y-6">
            {generatedItinerary.dailyPlan?.map((day: DailyItinerary, dayIndex: number) => (
              <details key={dayIndex} className="bg-white p-4 rounded-lg shadow-sm group" open={dayIndex === 0}>
                <summary className="font-semibold text-xl text-yellow-700 cursor-pointer group-hover:text-yellow-800">
                  Day {day.day}: {day.title || `Exploring ${generatedItinerary.destination}`}
                </summary>
                <div className="mt-4 space-y-3 text-gray-700">
                  <div>
                    <h4 className="font-semibold text-md text-gray-800">Morning:</h4>
                    {renderActivity(day.morning, "Morning")}
                  </div>
                  <div>
                    <h4 className="font-semibold text-md text-gray-800">Afternoon:</h4>
                    {renderActivity(day.afternoon, "Afternoon")}
                  </div>
                  <div>
                    <h4 className="font-semibold text-md text-gray-800">Evening:</h4>
                    {renderActivity(day.evening, "Evening")}
                  </div>
                  {day.foodSuggestions && day.foodSuggestions.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-md text-gray-800">Food Suggestions:</h4>
                      <ul className="list-disc list-inside ml-4 text-sm">
                        {day.foodSuggestions.map((food, foodIdx) => <li key={foodIdx}>{food}</li>)}
                      </ul>
                    </div>
                  )}
                  {day.notes && (
                     <div className="mt-2 p-2 bg-gray-100 rounded text-sm">
                      <h5 className="font-semibold">Notes for Day {day.day}:</h5>
                      <p className="whitespace-pre-wrap">{day.notes}</p>
                    </div>
                  )}
                </div>
              </details>
            ))}
          </div>
        </div>
      )}
    </PageWrapper>
  );
};
