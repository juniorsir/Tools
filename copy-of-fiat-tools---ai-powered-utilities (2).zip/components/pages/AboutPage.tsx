
import React from 'react';
import { PageWrapper } from '../common/PageWrapper';
import { APP_NAME, InformationCircleIcon } from '../../constants';

export const AboutPage: React.FC = () => {
  return (
    <PageWrapper title="About Us">
       <div className="flex items-center text-gray-600 mb-6">
        <InformationCircleIcon className="w-8 h-8 mr-3 text-gray-500" />
        <p className="text-lg">
          Learn more about {APP_NAME} and our mission.
        </p>
      </div>
      <div className="space-y-4 text-gray-700 prose prose-indigo max-w-none">
        <p>
          {APP_NAME} is a demonstration project showcasing the power and versatility of modern AI technologies, 
          particularly the Google Gemini API. Our goal is to provide a suite of useful, easy-to-use tools 
          that leverage artificial intelligence to solve real-world problems and enhance creativity.
        </p>
        <p>
          This application is built with React, TypeScript, and Tailwind CSS for a responsive and modern user experience. 
          We are committed to exploring the frontiers of AI and bringing its benefits to a wider audience.
        </p>
        <h3 className="text-xl font-semibold pt-4">Our Vision</h3>
        <p>
          We envision a future where AI tools are seamlessly integrated into daily workflows, empowering individuals 
          and businesses to achieve more. {APP_NAME} is a step towards that future, offering a glimpse into 
          the potential of generative AI.
        </p>
        <h3 className="text-xl font-semibold pt-4">Technology Stack</h3>
        <ul>
          <li>Frontend: React 18, TypeScript, Tailwind CSS</li>
          <li>AI: Google Gemini API (@google/genai)</li>
          <li>Routing: React Router (HashRouter)</li>
        </ul>
        <p>
          Thank you for visiting {APP_NAME}. We hope you find our tools useful and inspiring!
        </p>
      </div>
    </PageWrapper>
  );
};
