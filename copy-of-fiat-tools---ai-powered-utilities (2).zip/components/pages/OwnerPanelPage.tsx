import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { PageWrapper } from '../common/PageWrapper';
import { ErrorMessage } from '../common/ErrorMessage';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { ROUTES, OWNER_PASSWORD, ShieldCheckIcon } from '../../constants';

export const OwnerPanelPage: React.FC = () => {
  const { currentUser, isOwner, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [password, setPassword] = useState<string>('');
  const [panelVerified, setPanelVerified] = useState<boolean>(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [notificationMessage, setNotificationMessage] = useState<string>('');
  const [updateMessage, setUpdateMessage] = useState<string>('');
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && !currentUser) {
      navigate(ROUTES.HOME); // Redirect if not logged in
    } else if (!authLoading && currentUser && !isOwner) {
      navigate(ROUTES.HOME); // Redirect if logged in but not owner
    }
  }, [currentUser, isOwner, authLoading, navigate]);

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === OWNER_PASSWORD) {
      setPanelVerified(true);
      setPasswordError(null);
    } else {
      setPasswordError('Incorrect password. Access denied.');
      setPanelVerified(false);
    }
  };

  const handleSendNotification = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would call a backend service
    console.log('Sending notification:', notificationMessage);
    setFeedback(`Simulated: Notification "${notificationMessage}" sent to all users.`);
    setNotificationMessage('');
    setTimeout(() => setFeedback(null), 3000);
  };

  const handleSendUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would call a backend service
    console.log('Sending update:', updateMessage);
    setFeedback(`Simulated: Update "${updateMessage}" pushed.`);
    setUpdateMessage('');
    setTimeout(() => setFeedback(null), 3000);
  };

  if (authLoading) {
    return <PageWrapper title="Owner Panel"><LoadingSpinner /></PageWrapper>;
  }

  if (!currentUser || !isOwner) {
    // This case should ideally be handled by the useEffect redirect,
    // but as a fallback:
    return (
      <PageWrapper title="Access Denied">
        <p className="text-center text-red-600">You do not have permission to view this page.</p>
      </PageWrapper>
    );
  }

  if (!panelVerified) {
    return (
      <PageWrapper title="Owner Panel - Verification">
        <div className="flex items-center text-gray-600 mb-6">
            <ShieldCheckIcon className="w-8 h-8 mr-3 text-orange-500" />
            <p className="text-lg">
            This area is restricted. Please enter the owner password to proceed.
            </p>
        </div>
        <form onSubmit={handlePasswordSubmit} className="space-y-4 max-w-sm mx-auto">
          <div>
            <label htmlFor="owner-password" className="block text-sm font-medium text-gray-700">Owner Password</label>
            <input
              type="password"
              id="owner-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
              required
            />
          </div>
          {passwordError && <ErrorMessage message={passwordError} />}
          <button
            type="submit"
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-orange-600 hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
          >
            Verify Access
          </button>
        </form>
      </PageWrapper>
    );
  }

  return (
    <PageWrapper title="Owner Dashboard">
      <p className="text-lg text-gray-700 mb-6">Welcome, Owner! Manage your application from here.</p>
      
      {feedback && (
        <div className="mb-4 p-3 bg-green-100 border-l-4 border-green-500 text-green-700">
          {feedback}
        </div>
      )}

      <div className="space-y-8">
        {/* See Users Section */}
        <section className="p-6 bg-white rounded-lg shadow">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">User Management</h2>
          <p className="text-gray-600 mb-2">Currently logged in as: <strong>{currentUser.email}</strong></p>
          <p className="text-gray-600">
            In a full-stack application, this section would list all registered users,
            allow you to manage their roles, or view their activity. For this frontend demo,
            we only display your information.
          </p>
          {/* Mock user list could be added here if desired, but would be static */}
        </section>

        {/* Send Notification Section */}
        <section className="p-6 bg-white rounded-lg shadow">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Send Notification</h2>
          <form onSubmit={handleSendNotification} className="space-y-4">
            <div>
              <label htmlFor="notification-message" className="block text-sm font-medium text-gray-700">Notification Content</label>
              <textarea
                id="notification-message"
                rows={3}
                value={notificationMessage}
                onChange={(e) => setNotificationMessage(e.target.value)}
                className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                placeholder="Enter notification text for all users..."
                required
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              Send Notification (Simulated)
            </button>
          </form>
        </section>

        {/* Send Updates Section */}
        <section className="p-6 bg-white rounded-lg shadow">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Push Application Update</h2>
          <form onSubmit={handleSendUpdate} className="space-y-4">
            <div>
              <label htmlFor="update-message" className="block text-sm font-medium text-gray-700">Update Description</label>
              <textarea
                id="update-message"
                rows={3}
                value={updateMessage}
                onChange={(e) => setUpdateMessage(e.target.value)}
                className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500 sm:text-sm"
                placeholder="e.g., New feature X launched! Performance improvements."
                required
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500"
            >
              Push Update (Simulated)
            </button>
          </form>
          <p className="mt-3 text-xs text-gray-500">
            This simulates pushing an update announcement or triggering a client refresh mechanism.
            Actual app updates would involve deployment processes.
          </p>
        </section>
      </div>
    </PageWrapper>
  );
};
