
import React, { useState, useCallback } from 'react';
import { analyzeTextWithGemini } from '../../services/geminiService';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { ErrorMessage } from '../common/ErrorMessage';
import { PageWrapper } from '../common/PageWrapper';
import { DocumentTextIcon } from '../../constants';
import { GroundingChunk, TextAnalysisResult } from '../../types';

export const TextAnalyzerPage: React.FC = () => {
  const [inputText, setInputText] = useState<string>('');
  const [analysisResult, setAnalysisResult] = useState<TextAnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [useSearch, setUseSearch] = useState<boolean>(false);

  const handleSubmit = useCallback(async (event: React.FormEvent) => {
    event.preventDefault();
    if (!inputText.trim()) {
      setError('Please enter some text to analyze.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);

    try {
      const prompt = `Analyze the following text. Provide a concise summary and highlight key insights. Text: "${inputText}"`;
      const result = await analyzeTextWithGemini(prompt, useSearch);
      setAnalysisResult(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
      console.error("Text analysis error:", err);
    } finally {
      setIsLoading(false);
    }
  }, [inputText, useSearch]);

  return (
    <PageWrapper title="Text Analyzer">
      <div className="flex items-center text-gray-600 mb-6">
        <DocumentTextIcon className="w-8 h-8 mr-3 text-blue-500" />
        <p className="text-lg">
          Enter text below to get an AI-powered analysis. You can optionally use Google Search grounding for more current information.
        </p>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="text-input" className="block text-sm font-medium text-gray-700 mb-1">
            Your Text
          </label>
          <textarea
            id="text-input"
            rows={8}
            className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-150 ease-in-out"
            placeholder="Paste or type your text here..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={isLoading}
          />
        </div>

        <div className="flex items-center">
            <input
                id="use-search"
                type="checkbox"
                className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                checked={useSearch}
                onChange={(e) => setUseSearch(e.target.checked)}
                disabled={isLoading}
            />
            <label htmlFor="use-search" className="ml-2 block text-sm text-gray-900">
                Use Google Search grounding (for recent topics)
            </label>
        </div>

        <button
          type="submit"
          disabled={isLoading || !inputText.trim()}
          className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition duration-150 ease-in-out"
        >
          {isLoading ? (
            <>
              <LoadingSpinner /> <span className="ml-2">Analyzing...</span>
            </>
          ) : (
            'Analyze Text'
          )}
        </button>
      </form>

      {error && <ErrorMessage message={error} />}

      {analysisResult && (
        <div className="mt-8 p-6 bg-gray-50 rounded-lg shadow">
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">Analysis Result:</h3>
          <div className="prose prose-blue max-w-none text-gray-700 whitespace-pre-wrap">
            {analysisResult.analysis}
          </div>
          {analysisResult.sources && analysisResult.sources.length > 0 && (
            <div className="mt-6">
              <h4 className="text-lg font-semibold text-gray-700 mb-2">Sources (from Google Search):</h4>
              <ul className="list-disc list-inside space-y-1">
                {analysisResult.sources.map((source: GroundingChunk, index: number) => (
                  <li key={index} className="text-sm">
                    <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                      {source.web.title || source.web.uri}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </PageWrapper>
  );
};
