
import React from 'react';
import { Link } from 'react-router-dom';
import { APP_NAME, ROUTES, TOOLS_CONFIG, WrenchScrewdriverIcon } from '../../constants';
import { ToolCard } from '../ToolCard';

export const HomePage: React.FC = () => {
  return (
    <div className="space-y-12">
      <section className="text-center py-12 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl shadow-2xl">
        <div className="container mx-auto px-6">
          <WrenchScrewdriverIcon className="w-24 h-24 mx-auto mb-6 text-white opacity-80" />
          <h1 className="text-4xl md:text-5xl font-extrabold mb-4">Welcome to {APP_NAME}!</h1>
          <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto">
            Your one-stop solution for powerful AI-driven utilities. Explore our tools to enhance your productivity and creativity.
          </p>
          <Link
            to={ROUTES.TOOLS}
            className="bg-white text-blue-600 font-semibold py-3 px-8 rounded-lg shadow-md hover:bg-gray-100 transition duration-300 text-lg"
          >
            Explore Tools
          </Link>
        </div>
      </section>

      <section>
        <h2 className="text-3xl font-bold text-gray-800 text-center mb-8">Featured Tools</h2>
        <div className="grid md:grid-cols-2 gap-8">
          {TOOLS_CONFIG.slice(0, 2).map(tool => ( // Show first 2 tools or all if less
            <ToolCard key={tool.id} tool={tool} />
          ))}
        </div>
        {TOOLS_CONFIG.length > 2 && (
           <div className="text-center mt-8">
             <Link
                to={ROUTES.TOOLS}
                className="text-blue-600 hover:text-blue-800 font-medium transition duration-300"
              >
                View All Tools &rarr;
            </Link>
           </div>
        )}
      </section>

       <section className="bg-white p-8 rounded-xl shadow-xl">
        <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">Why Choose {APP_NAME}?</h2>
        <div className="grid md:grid-cols-3 gap-8 text-center">
          <div>
            <div className="p-3 bg-blue-100 rounded-full inline-block mb-3">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Powerful AI</h3>
            <p className="text-gray-600">Leverage cutting-edge AI models for accurate and insightful results.</p>
          </div>
          <div>
            <div className="p-3 bg-green-100 rounded-full inline-block mb-3">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Modern UI</h3>
            <p className="text-gray-600">Enjoy a seamless and intuitive user experience with our modern design.</p>
          </div>
          <div>
            <div className="p-3 bg-purple-100 rounded-full inline-block mb-3">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" /></svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Versatile Tools</h3>
            <p className="text-gray-600">A growing collection of tools to meet your diverse needs.</p>
          </div>
        </div>
      </section>
    </div>
  );
};
