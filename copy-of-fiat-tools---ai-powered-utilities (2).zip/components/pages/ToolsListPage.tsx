
import React from 'react';
import { TOOLS_CONFIG } from '../../constants';
import { ToolCard } from '../ToolCard';
import { PageWrapper } from '../common/PageWrapper';

export const ToolsListPage: React.FC = () => {
  return (
    <PageWrapper title="Our Tools">
      <p className="mb-8 text-lg text-gray-600">
        Discover our suite of AI-powered tools designed to help you with various tasks. Click on a tool to get started.
      </p>
      {TOOLS_CONFIG.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6 sm:gap-8">
          {TOOLS_CONFIG.map(tool => (
            <ToolCard key={tool.id} tool={tool} />
          ))}
        </div>
      ) : (
        <p className="text-gray-500">No tools available at the moment. Please check back later.</p>
      )}
    </PageWrapper>
  );
};
