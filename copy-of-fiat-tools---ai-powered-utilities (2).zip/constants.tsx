import React from 'react';
import { HomePage } from './components/pages/HomePage';
import { ToolsListPage } from './components/pages/ToolsListPage';
import { TextAnalyzerPage } from './components/pages/TextAnalyzerPage';
import { ImageGeneratorPage } from './components/pages/ImageGeneratorPage';
import { AboutPage } from './components/pages/AboutPage';
import { RecipeGeneratorPage } from './components/pages/RecipeGeneratorPage';
import { WorkoutPlannerPage } from './components/pages/WorkoutPlannerPage';
import { TravelItineraryPage } from './components/pages/TravelItineraryPage';
import { CodeGeneratorPage } from './components/pages/CodeGeneratorPage'; 
import { StoryWriterPage } from './components/pages/StoryWriterPage'; 
import { OwnerPanelPage } from './components/pages/OwnerPanelPage'; // New
import { Tool } from './types';

// SVG Icons (Heroicons outline style)
const DocumentTextIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
  </svg>
);

const PhotoIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="m2.25 15.75 5.159-5.159a2.25 2.25 0 0 1 3.182 0l5.159 5.159m-1.5-1.5 1.409-1.409a2.25 2.25 0 0 1 3.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 0 0 1.5-1.5V6a1.5 1.5 0 0 0-1.5-1.5H3.75A1.5 1.5 0 0 0 2.25 6v12a1.5 1.5 0 0 0 1.5 1.5Zm10.5-11.25h.008v.008h-.008V8.25Zm.158 0a.75.75 0 1 0-1.5 0 .75.75 0 0 0 1.5 0Z" />
  </svg>
);

const InformationCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="m11.25 11.25.041-.02a.75.75 0 0 1 1.063.852l-.708 2.836a.75.75 0 0 0 1.063.853l.041-.021M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-3.75h.008v.008H12V8.25Z" />
  </svg>
);

const HomeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h7.5" />
  </svg>
);

const WrenchScrewdriverIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M11.42 15.17 17.25 21A2.652 2.652 0 0 0 21 17.25l-5.83-5.83M11.42 15.17A2.652 2.652 0 0 1 7.593 18.95l-4.846 4.847a2.652 2.652 0 0 1-3.752-3.751l4.846-4.848A2.652 2.652 0 0 1 11.42 15.17Zm0 0L8.847 12.6A2.652 2.652 0 0 1 12.6 8.847l5.83 5.83M11.42 15.17A2.652 2.652 0 0 0 15.17 11.42l5.83-5.83a2.652 2.652 0 0 0-3.752-3.752L11.42 7.593A2.652 2.652 0 0 0 7.593 11.42l3.827 3.75Z" />
  </svg>
);

const ChefHatIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 21H10.5C8.25 21 7.5 19.5 7.5 18V15C7.5 13.5 6.75 12 5.25 12C3.75 12 3 13.5 3 15V16.5M13.5 21V19.5C13.5 18.75 13.875 18 14.625 18H16.5C18.75 18 19.5 16.5 19.5 15V12C19.5 10.5 18.75 9 17.25 9C15.75 9 15 10.5 15 12V15C15 16.5 14.25 18 12.75 18H11.25M13.5 21V10.5M10.5 7.5C10.5 5.25 12.75 3 15 3C17.25 3 19.5 5.25 19.5 7.5C19.5 9.75 17.25 12 15 12H9C6.75 12 4.5 9.75 4.5 7.5C4.5 5.25 6.75 3 9 3C10.5 3 10.5 4.5 10.5 7.5Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 12C9.75 12.75 9.525 13.5 9 13.5C8.475 13.5 8.25 12.75 8.25 12" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 15C15.75 15.75 15.525 16.5 15 16.5C14.475 16.5 14.25 15.75 14.25 15" />
 </svg>
);

const DumbbellIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 7.5h.01M6.75 16.5h.01M17.25 7.5h.01M17.25 16.5h.01M4.5 12H2.25m19.5 0H19.5M9 4.5V2.25m6 0V4.5m0 15v2.25m-6 0V19.5M5.625 7.5A2.625 2.625 0 0 1 8.25 4.875h7.5A2.625 2.625 0 0 1 18.375 7.5v9A2.625 2.625 0 0 1 15.75 19.125h-7.5A2.625 2.625 0 0 1 5.625 16.5v-9Z" />
  </svg>
);

const GlobeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.743 10.043A8.953 8.953 0 0 1 12 3.558a8.953 8.953 0 0 1 8.257 6.485M1.376 13.877A8.953 8.953 0 0 1 12 20.442a8.953 8.953 0 0 1 10.624-6.565M12 3v18M3 12h18" />
  </svg>
);

const CodeBracketIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 6.75 22.5 12l-5.25 5.25m-10.5 0L1.5 12l5.25-5.25m7.5-3-4.5 16.5" />
  </svg>
);

const BookOpenIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 0 0 6 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 0 1 6 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 0 1 6-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0 0 18 18a8.967 8.967 0 0 0-6 2.292m0-14.25v14.25" />
  </svg>
);

const ShieldCheckIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z" />
  </svg>
);


export const APP_NAME = "Fiat Tools";
export const OWNER_EMAIL = "owner@fiattools.com"; // Replace with actual owner's Google email
export const OWNER_PASSWORD = "junior_sir_official965565"; // For client-side panel access check

export const ROUTES = {
  HOME: '/',
  TOOLS: '/tools',
  TEXT_ANALYZER: '/tools/text-analyzer',
  IMAGE_GENERATOR: '/tools/image-generator',
  RECIPE_GENERATOR: '/tools/recipe-generator',
  WORKOUT_PLANNER: '/tools/workout-planner',
  TRAVEL_ITINERARY_PLANNER: '/tools/travel-itinerary-planner',
  CODE_GENERATOR: '/tools/code-generator', 
  STORY_WRITER: '/tools/story-writer', 
  ABOUT: '/about',
  OWNER_PANEL: '/owner-panel', // New
};

export const TOOLS_CONFIG: Tool[] = [
  {
    id: 'text-analyzer',
    name: 'Text Analyzer',
    description: 'Analyze text for insights, summaries, or sentiment using AI. Supports Google Search grounding for up-to-date information.',
    path: ROUTES.TEXT_ANALYZER,
    icon: <DocumentTextIcon className="w-12 h-12 text-blue-500" />,
    component: TextAnalyzerPage,
  },
  {
    id: 'image-generator',
    name: 'Image Generator',
    description: 'Create stunning images from textual descriptions using generative AI.',
    path: ROUTES.IMAGE_GENERATOR,
    icon: <PhotoIcon className="w-12 h-12 text-purple-500" />,
    component: ImageGeneratorPage,
  },
  {
    id: 'recipe-generator',
    name: 'Recipe Generator',
    description: 'Generate creative recipes based on ingredients you have, dietary needs, and preferred cuisine. Never wonder what to cook again!',
    path: ROUTES.RECIPE_GENERATOR,
    icon: <ChefHatIcon className="w-12 h-12 text-green-500" />,
    component: RecipeGeneratorPage,
  },
  {
    id: 'workout-planner',
    name: 'Workout Planner',
    description: 'Get a personalized workout plan tailored to your fitness goals, available time, preferred activities, and current fitness level.',
    path: ROUTES.WORKOUT_PLANNER,
    icon: <DumbbellIcon className="w-12 h-12 text-red-500" />,
    component: WorkoutPlannerPage,
  },
  {
    id: 'travel-itinerary-planner',
    name: 'Travel Itinerary Planner',
    description: 'Plan your next adventure! Get a customized travel itinerary with suggested activities, sights, and food based on your destination and interests.',
    path: ROUTES.TRAVEL_ITINERARY_PLANNER,
    icon: <GlobeIcon className="w-12 h-12 text-yellow-500" />,
    component: TravelItineraryPage,
  },
  { 
    id: 'code-generator',
    name: 'Code Generator',
    description: 'Generate code snippets in various languages based on your problem description. Includes explanations of the generated code.',
    path: ROUTES.CODE_GENERATOR,
    icon: <CodeBracketIcon className="w-12 h-12 text-indigo-500" />,
    component: CodeGeneratorPage,
  },
  { 
    id: 'story-writer',
    name: 'AI Story Writer',
    description: 'Craft unique stories with AI assistance. Provide genre, characters, plot ideas, and desired length to generate a narrative.',
    path: ROUTES.STORY_WRITER,
    icon: <BookOpenIcon className="w-12 h-12 text-pink-500" />,
    component: StoryWriterPage,
  },
];

export const NAV_LINKS_BASE = [
    { name: 'Home', path: ROUTES.HOME, icon: <HomeIcon className="w-5 h-5 mr-2" /> },
    { name: 'Tools', path: ROUTES.TOOLS, icon: <WrenchScrewdriverIcon className="w-5 h-5 mr-2" /> },
    { name: 'About', path: ROUTES.ABOUT, icon: <InformationCircleIcon className="w-5 h-5 mr-2" /> },
];

// Owner Panel link will be added dynamically in Navbar
export const OWNER_NAV_LINK = { 
  name: 'Owner Panel', 
  path: ROUTES.OWNER_PANEL, 
  icon: <ShieldCheckIcon className="w-5 h-5 mr-2" /> 
};

export { 
    DocumentTextIcon, PhotoIcon, InformationCircleIcon, HomeIcon, WrenchScrewdriverIcon,
    ChefHatIcon, DumbbellIcon, GlobeIcon,
    CodeBracketIcon, BookOpenIcon, ShieldCheckIcon // Export new icons
};
