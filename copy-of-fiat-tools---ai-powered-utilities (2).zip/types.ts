import { ReactNode } from 'react';

export interface Tool {
  id: string;
  name: string;
  description: string;
  path: string;
  icon: ReactNode;
  component: React.FC;
}

export interface GroundingChunkWeb {
  uri: string;
  title: string;
}

export interface GroundingChunk {
  web: GroundingChunkWeb;
}

export interface TextAnalysisResult {
  analysis: string;
  sources?: GroundingChunk[];
}

// --- New Tool Specific Types ---

// Recipe Generator
export interface RecipeIngredient {
  name: string;
  quantity: string;
}

export interface Recipe {
  recipeName: string;
  description: string;
  prepTime: string;
  cookTime: string;
  servings: string;
  ingredients: RecipeIngredient[];
  instructions: string[];
  notes?: string;
  cuisineType?: string;
  mealType?: string;
}

// Workout Planner
export interface WorkoutExercise {
  name: string;
  sets: string | number;
  reps: string | number;
  rest?: string;
  duration?: string; // For timed exercises
}

export interface WorkoutDay {
  dayOfWeek?: string; // e.g., "Monday" or "Day 1"
  focus: string; // e.g., "Upper Body", "Cardio & Core"
  warmUp?: string[];
  exercises: WorkoutExercise[];
  coolDown?: string[];
}

export interface WorkoutPlan {
  planName: string;
  description?: string;
  fitnessLevel?: string;
  daysPerWeek?: number;
  goal?: string;
  dailySchedule: WorkoutDay[];
  notes?: string;
}

// Travel Itinerary Planner
export interface ItineraryActivity {
  activity: string;
  description?: string;
  estimatedTime?: string;
  location?: string;
}

export interface DailyItinerary {
  day: number;
  title?: string; // e.g., "Arrival and Historical Charm"
  morning?: ItineraryActivity;
  afternoon?: ItineraryActivity;
  evening?: ItineraryActivity;
  foodSuggestions?: string[];
  notes?: string;
}

export interface TravelItinerary {
  tripName: string;
  destination: string;
  durationDays: number;
  interestsMentioned?: string[];
  budgetLevel?: string;
  overallNotes?: string;
  dailyPlan: DailyItinerary[];
}

// Code Generator
export interface CodeGenerationResult {
  generatedCode: string;
  explanation: string;
  language: string;
}

// Story Writer
export interface StoryResult {
  title: string;
  story: string;
  genre?: string;
  charactersInvolved?: string[];
}