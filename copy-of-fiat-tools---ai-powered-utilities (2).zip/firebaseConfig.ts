// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
// IMPORTANT: Replace with your actual Firebase project configuration.
// The API key provided by the user is used here.
export const firebaseConfig = {
  apiKey: "AIzaSyDCB52OhrPoB2JduiK-cKVpA863DRCojgk", // User-provided API Key
  authDomain: "tools-b1fac.firebaseapp.com",
  projectId: "tools-b1fac",
  storageBucket: "tools-b1fac.firebasestorage.app",
  messagingSenderId: "1003083351698",
  appId: "1:1003083351698:web:4362991ad6c7de40ab084b",
  measurementId: "G-0P5P712PVL" // Optional
};
