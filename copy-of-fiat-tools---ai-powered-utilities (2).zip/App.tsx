import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { HomePage } from './components/pages/HomePage';
import { ToolsListPage } from './components/pages/ToolsListPage';
import { AboutPage } from './components/pages/AboutPage';
import { NotFoundPage } from './components/pages/NotFoundPage';
import { OwnerPanelPage } from './components/pages/OwnerPanelPage'; // New
import { AuthProvider } from './contexts/AuthContext'; // New
import { TOOLS_CONFIG, ROUTES } from './constants';

const App: React.FC = () => {
  return (
    <AuthProvider> {/* Wrap with AuthProvider */}
      <HashRouter>
        <Layout>
          <Routes>
            <Route path={ROUTES.HOME} element={<HomePage />} />
            <Route path={ROUTES.TOOLS} element={<ToolsListPage />} />
            {TOOLS_CONFIG.map(tool => (
              <Route key={tool.id} path={tool.path} element={<tool.component />} />
            ))}
            <Route path={ROUTES.ABOUT} element={<AboutPage />} />
            <Route path={ROUTES.OWNER_PANEL} element={<OwnerPanelPage />} /> {/* New route */}
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </Layout>
      </HashRouter>
    </AuthProvider>
  );
};

export default App;
